#include "mode2.h"
#include "control.h"
#include "tim.h"
#include "gpio.h"
#include "trajectory.h"
#include "stm32f1xx_it.h"

#define BASE_SPEED 0.5f   // 基础前进速度（0~1）
#define Kp 0.4f           // 转向比例系数
#define DEAD_ZONE 0.05f   // 偏差死区
#define V_HALF  20.0f   // 半速前进 ≈ 20 cm/s（你实测后改）
extern UART_HandleTypeDef huart1;

// PWM 映射函数
extern uint16_t pwm_map(float duty);


void mode2_loop(void){
    init_motors();
    traj_init();


    num_count = 0;
    while(rxBuffer[1]!='s'){

        // 读取左右避障传感器数字信号
    	uint8_t left_detect  = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4); // 0 = 左边有物体
    	uint8_t right_detect = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5); // 0 = 右边有物体


        // --- 1️⃣ 无物体 → 停止 ---
        if(left_detect && right_detect){
            stop_motors();
            traj_update(0, 0,0);

        }
        // --- 2️⃣ 左无右有 → 原地右转 ---
        else if(!left_detect && right_detect){
            turn_right_half();
            traj_update(V_HALF, -V_HALF,1);
        }
        // --- 3️⃣ 右无左有 → 原地左转 ---
        else if(left_detect && !right_detect){
            turn_left_half();
            traj_update(-V_HALF, V_HALF,1);
        }
        // --- 4️⃣ 左右都检测到 → 前进 / 平滑跟随 ---
        else if(!left_detect && !right_detect){


            forward_half();
            traj_update(V_HALF, V_HALF,1);


        }

        HAL_Delay(10); // 控制周期 10ms
    }
}
//this function should  move to the screen part
//uint16_t pre_x(0), pre_y(lcddev.height);//boundary
//uint16_t sampling_para = 5;
//void path_show(uint16_t x, uint16_t y){
//    static int pulse = 0;
//
//    TP_Draw_Big_Point(x,y,BLUE);
//    pulse++;
//    if(pulse == sampling_para){
//        //lcd_draw_bline(pre_x, pre_y, x, y, 3, RED);
//        u16 temp = POINT_COLOR;
//		POINT_COLOR=BLUE;
//        LCD_DrawLine(pre_x, pre_y, x, y);
//        POINT_COLOR = temp;
//        pre_x = x;
//        pre_y = y;
//        pulse = 0;
//    }
//
//}
