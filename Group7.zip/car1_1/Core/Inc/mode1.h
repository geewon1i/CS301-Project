#ifndef __MODE1_H__
#define __MODE1_H__
#include "stm32f1xx_hal.h"
void mode1_loop(void);

void execute_path(void);
int turn_time;
int move_time;

#endif
